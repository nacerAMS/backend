import { useState, useEffect } from "react";
import { getRequest } from "../utils/services";
import { baseUrl } from "../utils/services";

export const userfetchRecipientUser = (chat, user)=>{

    const [recipientUser, setRecipientUser] = useState(null);

    const recipientId = chat?.members.find((email) => email !== user?.email)

    useEffect(()=>{

        
        const getUser = async()=>{
            if (!recipientId) return null
            const response=  await getRequest(`${baseUrl}/auth/finduser/${recipientId}`)

            setRecipientUser(response);

        };
        getUser()
        
    },[recipientId]);
  

    return {recipientUser}

}