import { createContext, useState, useEffect, useCallback } from "react";
import { getRequest, baseUrl, postRequest } from "../src/utils/services";

export const ChatContext = createContext();


export const ChatContextProvider = ({children, user}) =>{
    const [userChats, setUserChats] = useState(null);
    const [isUserChatsLoaing, setIsUserChatsLoaing] = useState(false);
    const [userChatsError, setUserChatsError] = useState(null);
    const [PotentailChats, setPotentailChats] = useState([]);
    const [currentChat, setCurrentChat] = useState(null);
    const [messages, setMessages] = useState(null);
    const [isMessagesLoading, setIsMessagesLoading] = useState(false);
    const [messagesError, setMessagesError] = useState(null);
    const [newMessage, setNewMessage] = useState(null);
    const [sendTextMessagesError, setSendTextMessagesError] = useState(null);

     
    useEffect(()=>{
        
        const getUsers = async()=>{
            
            const response = await getRequest(`${baseUrl}/auth/users`);
            if (response.error) {  
                return console.error("error fetching users", response)
            };

            const pChats =response.filter((u)=>{
                let isChatcreated = false;
                if (user?.email === u.email){return false}

                
                    isChatcreated =userChats?.some((chat)=>{
                        return (chat.members[0]=== u.email || chat.members[1] === u.email)
                    })
                
                return !isChatcreated;
                
            });

            setPotentailChats(pChats);

        };
        getUsers();
    },[userChats]);

    
    useEffect(()=>{
        user =localStorage.getItem("User")
        const getMessages = async()=>{
                setIsMessagesLoading(true);
                setMessagesError(null);

                let response;
                console.log("currentChat", currentChat)
                if(currentChat){
                response = await getRequest(`${baseUrl}/messages/${currentChat._id}`);
            }

                setIsMessagesLoading(false);
                setMessages(response);
            
        }

        getMessages()
    },[currentChat]);


    useEffect(()=>{
        
        const getUserChat = async()=>{

                setIsUserChatsLoaing(true);
                setUserChatsError(null);
                const response = await getRequest(`${baseUrl}/chats/user/${user?.email}`);

                setIsUserChatsLoaing(false);

                if (response.error) {
                    return setUserChatsError(response);
                }
                setUserChats(response);
            
        }

        getUserChat()
    },[user]);


    const sendTextMessage = useCallback(async(textMessage, sender, currentChatId, setTextMessage)=>{

        if (!textMessage) return console.log("message is empty...");

        const response = await postRequest(`${baseUrl}/messages/create-message`, JSON.stringify({
            chat_id: currentChatId,
            sender_id: sender ,
            message: textMessage
        }));

        if (response.error) {
            return setSendTextMessagesError(response);
        }
        setNewMessage(response);
        setMessages((prev)=>[...prev, response])

        setTextMessage("");

    },[]);


    const updateCurrentchat = useCallback(async(chat)=>{
        setCurrentChat(chat)
    },[])


    const createChat = useCallback(async(First, Second)=>{
        const response = await postRequest(`${baseUrl}/chats/create-chat`, JSON.stringify({
             members :[First.email,Second.email]
        }));
        setUserChats(prev => prev === null ? [response] : [...prev, response]);
    },[setUserChats])

    

    return <ChatContext.Provider value={{
            userChats,
            isUserChatsLoaing,
            userChatsError,
            PotentailChats,
            createChat,
            updateCurrentchat,
            messages,
            isMessagesLoading,
            messagesError,
            currentChat,
            sendTextMessage
            }}>
            {children}
            </ChatContext.Provider>

}