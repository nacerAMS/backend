import { useContext, useState } from "react";
import { AuthContext } from "../../assist/Auth";
import { ChatContext } from "../../assist/chatContext";
import { userfetchRecipientUser } from "../../src/hooks/userfetchRecipient";
import { Stack } from "react-bootstrap";
import moment from "moment";
import InputEmoji from "react-input-emoji";


const ChatBox = () => {
    const {user}= useContext(AuthContext);
    const {currentChat, messages, isMessagesLoading,sendTextMessage} = useContext(ChatContext);
    const {recipientUser} = userfetchRecipientUser(currentChat, user);
    const [textMessage, setTextMessage] = useState("");


    if (!recipientUser){return(
        <p style={{textAlign: "center", width:"100%"}}>
            no conversation selected yet </p>
    )} ;


    return ( <Stack className="chat-box" gap={4}>
        <div className="chat-header">
            <strong>{recipientUser.username} </strong>
        </div>
        <Stack className="messages" gap={3}>
            {messages && messages.map((message, index)=><Stack key={index}
            className={`${message?.sender_id===currentChat?.members[0] ? 
                "message self align-start flex-grow-0" :
                "message align-end flex-grow-0"}`}>
                <span>{message.message} </span>
                <span>{moment(message.createdAt).calendar()} </span>
            </Stack>)}
        </Stack>
        <Stack direction="horizontal" gap={2} className="chat-input flex-grow-0">

                <InputEmoji value = {textMessage} onChange = {setTextMessage} fontFamily="nunito" borderColor="rgba(72,112,223, 0.2" />
                
                <button className="send-btn" onClick={()=>sendTextMessage(textMessage, user.email, currentChat._id, sendTextMessage)}> 
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitch" viewBox="0 0 16 16">
  <path d="M3.857 0 1 2.857v10.286h3.429V16l2.857-2.857H9.57L14.714 8V0zm9.714 7.429-2.285 2.285H9l-2 2v-2H4.429V1.143h9.142z"/>
  <path d="M11.857 3.143h-1.143V6.57h1.143zm-3.143 0H7.571V6.57h1.143z"/>
</svg></button>
        </Stack>
    </Stack> );
}
 
export default ChatBox;