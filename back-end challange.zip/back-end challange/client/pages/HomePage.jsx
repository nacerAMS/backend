import React from 'react';
import { Link } from 'react-router-dom';

const HomePage = () => {
  return (
    <div className="welcome-page">
      <h1>Welcome to Our Website!</h1>
      <p>Chat a create by </p>
      <p>Nacer Chakib Amrous </p>
      <Link to="/login" className="btn btn-primary">Get Started</Link>
    </div>
  );
};

export default HomePage;