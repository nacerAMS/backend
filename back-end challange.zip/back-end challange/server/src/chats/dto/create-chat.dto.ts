import { IsNotEmpty, IsArray } from 'class-validator';
export class CreateChatDto {
  
  readonly id: number;
  @IsNotEmpty()
  @IsArray()
  readonly members: Array<string>;
  @IsArray()
  readonly message: Array<string>;
}
