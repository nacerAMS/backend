import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { ChatsService } from './chats.service';
import { CreateChatDto } from './dto/create-chat.dto';


@Controller('chats')
export class ChatsController {
  constructor(private readonly chatsService: ChatsService) {}

 

  @Post('create-chat')
  async createChat(@Body() createChatDto: CreateChatDto) {
    return await this.chatsService.createChat(createChatDto);
  }

 
  @Get(':id')
  async getAllChatsByUserId(@Param(':id') id: string) {
    return await this.chatsService.findAllChats(id);
  }

  @Get('user/:email')
  async getUser(@Param('email') email: string) { 
    return await this.chatsService.findemail(email);   
  }
  @Get('get/:email1/:email2')
  async getChat(@Param('email1') email1: string, @Param('email2') email2: string) { 
    return await this.chatsService.findChat(email1, email2);   
  }

}
