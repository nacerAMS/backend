import { Controller, Get, Post, Body, Patch, Param, Delete, HttpException, HttpStatus,Request } from '@nestjs/common';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { LoginDto } from './dto/login.dto';

@Controller('auth')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post('/register')
  async create(@Body() createUserDto: CreateUserDto) {
    const user = await this.usersService.create(createUserDto)

    return  this.usersService.buildUserResponse(user) ;
  }

  @Post('/login')
  async login(@Body() loginDto: LoginDto) {
    const user = await this.usersService.loginUser(loginDto)

    return  this.usersService.buildUserResponse(user) ;
  }

  @Get('/users')
  async findAll(): Promise<any[]> {
    const users = await this.usersService.findAll();
    return users;
  }

  @Get('/finduser/:email')
  async findByEmail(@Param('email') email: string){
    return  await this.usersService.findByEmail(email);
    
  }

  
}
