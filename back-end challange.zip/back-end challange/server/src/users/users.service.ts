import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { InjectModel } from '@nestjs/mongoose';
import { User } from './entities/user.entity';
import { Model } from 'mongoose';
import { UserResponseType } from './types/userResponse.type';
import { LoginDto } from './dto/login.dto';
import {compare} from 'bcrypt'
import { sign } from 'jsonwebtoken';

@Injectable()
export class UsersService {
  allUsers: any;
  getAllUsers() {
    throw new Error('Method not implemented.');
  }
  constructor(@InjectModel(User.name) private userModel : Model <User>){ 
  }
  async create(createUserDto: CreateUserDto): Promise<User> {

    const user = await this.userModel.findOne({email: createUserDto.email})

    if(user){
      throw new HttpException('User already exists ', HttpStatus.UNPROCESSABLE_ENTITY)
    }

    const createdUser = new this.userModel(createUserDto)

    return createdUser.save()
  }


  findOne(id: number) {
    return `This action returns a #${id} user`;
  }

  update(id: number, updateUserDto: UpdateUserDto) {
    return `This action updates a #${id} user`;
  }

  remove(id: number) {
    return `This action removes a #${id} user`;
  }

  buildUserResponse(User: User): UserResponseType{
    if(User){
  return {
    username: User.username,
    email : User.email,
    token: this.generateJwt(User)
  }}
  }

  async loginUser(loginDto: LoginDto): Promise <User>{
    const user = await this.userModel.findOne({email: loginDto.email}).select('+password')

    if(!user){
      throw new HttpException('User not found ', HttpStatus.UNPROCESSABLE_ENTITY)
    }
    const isPasswordcorrect = await compare(loginDto.password, user.password)

    if(!isPasswordcorrect){
      throw new HttpException('password incorrect ', HttpStatus.UNPROCESSABLE_ENTITY)
    }

    return user
  }

  generateJwt(user: User): string {
  return sign({email: user.email},'JWT_SECRUT')
  }

  async findByEmail(email: string): Promise<User> {
    return this.userModel.findOne({email});
  }

  async findAll(){
    return this.userModel.find();
  }
  
  }
