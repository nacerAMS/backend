import { Types } from 'mongoose';

export class MessageDo {
  _id: string;
  sender_id: string;
  chat_id: string;
  message: string;

  constructor(props: Partial<MessageDo>) {
    this._id = props._id || null;
    this.sender_id = props.sender_id || null;
    this.chat_id = props.chat_id || null;
    this.message = props.message || null;
  }
}
