import { User } from "../entities/user.entity";

export type UserResponseType = Omit<User, 'password'>
& {token: string}